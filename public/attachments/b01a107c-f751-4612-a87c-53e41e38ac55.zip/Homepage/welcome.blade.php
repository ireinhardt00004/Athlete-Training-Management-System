<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Training Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
       
      
    </head>
    <body class="overflow-hidden" style="height: 100vh; width:100%;" >

        <nav id="NavBar" class="container z-3">
            <div class="row">
                <div class="col d-flex justify-content-start align-items-center p-2">
                    <h1 class="h4 fs-4 pla"><a href="#Home" class="text-decoration-none text-black"><span class="text-success">CvSU </span>Training Management</a></h1>
                </div>
                 <div class="col d-flex justify-content-end d-sm-flex text-center p-2">
                    <ul class="navbar-nav">
                         
                                                @if (Route::has('login'))
                                        <li class="ms-auto nav-item fs-5 fs-sm-2 d-flex justify-content-between align-items-center gap-4">
                                            
                                            @auth
                                                <a class="nav-link" aria-current="page" href="{{ url('/dashboard')}}"> <img src={{asset('assets/img/man.png')}}  alt="man" style="height: 42px; width:42px;"></a>
                                            @else
                                                <a class="nav-link" aria-current="page" href="{{ route('login') }}" >Log in</a>

                                                @if (Route::has('register'))
                                                    <a class="nav-link" aria-current="page" href="{{ route('register') }}" >Register</a>
                                                @endif
                                            @endauth
                                           
                                        </li >
                                    @endif
                                    
                                </ul>
                </div>
            </div>
            
        </nav>
        <main class="container-fluid scrollspy-example overflow-y-auto" style="height: 100%" data-bs-spy="scroll" data-bs-target="#NavBar" data-bs-root-margin="0px 0px -40%" data-bs-smooth-scroll="true">
            <div class="row " style="height: 100%">
                <div class="col-sm-12 col-md-12 col-lg-6" >
                    <div id="Home" class="d-flex justify-content-center align-items-end flex-column h-100 p-2" >
                        <h1 class="h1 text-success">Lorem ipsum dolor sit amet c</h1>
                        <p class="fs-4 w-75 text-wrap">Lorem ipsum dolor sit amet consectetur adipisicing elit. Recusandae aut perferendis repellendus, error minima, molestiae laboriosam soluta deleniti vel explicabo fugiat vero, veritatis facere? Quidem velit ex omnis natus minus.</p>
                    </div>
                    
                </div>
                <div class="col-sm-12 col-md-12 col-lg-6">
                    <div class="d-flex justify-content-center align-items-center flex-column h-100 p-2">
                         <img src={{asset('assets/img/runner.png')}} class="img-fluid" style="height:70%; width:70%;" alt="">
                    </div>
                   
                </div>
            </div>
           
            </div>
           
        </main>
    </body>
</html>
